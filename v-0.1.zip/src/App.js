import React from 'react';
import { Route, Routes } from 'react-router-dom';

import './App.css';
import Projects from './pages/projects/projects';
import Req from './pages/requieres/req';
import Profile from './pages/profile/profile';


export default function App() {
  return (
    <Routes>
      <Route path='/' element={<Projects />} />
      <Route path='/profile' element={<Profile />} />
      <Route path='/requieres' element={<Req />} />
    </Routes>
  );
}