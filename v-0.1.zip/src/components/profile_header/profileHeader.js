import React from 'react'
import { FaSearch } from 'react-icons/fa';
import { HiOutlineBell } from 'react-icons/hi';
import './profileHeader.css';

export default function ProfileHeader() {
  return (
    <div className='profile-header'>
      <div className='profile-header__settings'>
        <ul className='profile-header__options'>
          <li>
            <span><HiOutlineBell /></span>
          </li>
          <li>
            <span><HiOutlineBell /></span>
          </li>
          <li className='profile-header__daul-item'>
            <span>EN</span>
            <span className='active'>عربي</span>
          </li>
        </ul>
      </div>
      <div className='profile-header__search'>
        <span><FaSearch fontSize={15} /></span>
        <input type='search' className='r' placeholder='بحث......' />
      </div>
    </div>
  )
}
