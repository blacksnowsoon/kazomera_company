import React from 'react';
import SecondHeader from '../../components/second_header/secondHeader';
import MainHeader from '../../components/main_header/mainHeader';
import './req.css';
import Adds from '../../components/adds_section/adds';
import RightMneu from '../../components/right_menu/rightMenu';

export default function Req() {
  return (
    <div className='req'>
      <MainHeader />
      <SecondHeader />
      <main className='req__page'>
        <Adds />
        <div className='req__body'>

        </div>
        <div className='req__right'>
          <Adds />
          <RightMneu />
        </div>
      </main>
    </div>
  )
}
