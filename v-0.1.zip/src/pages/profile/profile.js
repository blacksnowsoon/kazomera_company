import React from 'react'
import ProfileHeader from '../../components/profile_header/profileHeader'
import MainNav from '../../components/main_nav/mainNav'
import './profile.css'
import Notifications from '../../components/notifications_section/notific'
import Correspondence from '../../components/correspondence_section/corresp'
import Articles from '../../components/articles/articles'

export default function Profile() {
  return (
    <div className='profile'>
      <ProfileHeader />
      <main className='profile__body'>
        <Notifications />
        <div className='profile__content'>
          {
            ['المشاريع', 'المساهمات', 'الاستثمارات', 'الثفقات', 'الإهتمامات']
            .map((obj, s) => <Articles heading={obj} base={true}  />)
            }
        </div>
        <Correspondence />
        <div className='profile__main-nav'>
          <MainNav />
        </div>
      </main>
    </div>
  )
}
