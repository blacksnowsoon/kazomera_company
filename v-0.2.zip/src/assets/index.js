import logo from './images/logo.png';
import logoAddress from './images/logo-address.png';

const images = {
    logo,
    logoAddress
}

export { 
    images 
}