import React from 'react'

export default function MenuPages() {
  return (
    <div className='menu-pages'>
        
    </div>
  )
}
